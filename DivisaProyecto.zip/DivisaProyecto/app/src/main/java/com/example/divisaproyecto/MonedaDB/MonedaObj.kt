package com.example.divisaproyecto.MonedaDB

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class MonedaObj {
    @PrimaryKey
    var base_code: String
    var result: String? = null
    var documentation: String? = null
    var terms_of_use: String? = null
    var time_last_update_unix: Long = 0
    var time_last_update_utc: String? = null
    var time_next_update_unix: Long = 0
    var time_next_update_utc: String? = null
    var conversion_rates: String? = null

    constructor(
        base_code: String,
        result: String?,
        documentation: String?,
        terms_of_use: String?,
        time_last_update_unix: Long,
        time_last_update_utc: String?,
        time_next_update_unix: Long,
        time_next_update_utc: String?,
        conversion_rates: String?
    ) {
        this.base_code = base_code
        this.result = result
        this.documentation = documentation
        this.terms_of_use = terms_of_use
        this.time_last_update_unix = time_last_update_unix
        this.time_last_update_utc = time_last_update_utc
        this.time_next_update_unix = time_next_update_unix
        this.time_next_update_utc = time_next_update_utc
        this.conversion_rates = conversion_rates
    }


}