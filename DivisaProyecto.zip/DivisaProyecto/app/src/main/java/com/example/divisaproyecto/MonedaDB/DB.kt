package com.example.divisaproyecto.MonedaDB

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [MonedaObjeto::class],
    version = 1
)
abstract class DB: RoomDatabase(){

    abstract fun daoMoneda(): DAOMoneda

}