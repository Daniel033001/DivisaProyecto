package com.example.divisaproyecto.MonedaDB

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DAOMoneda {
    @Query("Select * from MonedaObjeto")
    suspend fun obtenerAllMoneda(): List<MonedaObjeto>

    @Query("SELECT * FROM MonedaObjeto WHERE tipo_moneda= :tm")
    suspend fun obtenerUno(tm: String): MonedaObjeto

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMoneda(moneda: MonedaObjeto)

}